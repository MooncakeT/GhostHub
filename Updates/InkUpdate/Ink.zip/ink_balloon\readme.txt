Balloon to go with Ink!Sans ghost

Ghost tutorial & template created by @zarla-s (http://www.ashido.com/ukagaka/)