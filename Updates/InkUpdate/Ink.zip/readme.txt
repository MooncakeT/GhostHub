Ink!Sans ghost for use with SSP (or other desktop buddy program)

-Pet Ink's head
-Play games with Ink
-Get inspiration from Ink
-Ask Ink to run errands

Latest update:
-More dialouge!

Ink!Sans created by @comyet
Ghost tutorial & template created by @zarla-s
This ghost created by Mooncake

(Send feedback to Mooncake)