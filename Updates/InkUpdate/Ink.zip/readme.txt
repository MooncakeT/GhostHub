Ink!Sans ghost for use with SSP (or other similar desktop buddy program)

-Pet Ink's head
-Play with Ink
-Get inspiration from Ink
-Ask Ink to run errands
-Slight customization options

Latest update:
-Various new dialouges
-Chat with Ink
-Can now click Broomie
-Option for a more random talking interval

Ink!Sans created by @comyet
Ghost tutorial & template created by @zarla-s
This ghost created by Mooncake

(Send feedback to Mooncake)